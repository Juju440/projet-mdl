<?php
 include('configBdd.php'); 
 include('controlSes.php');
 if ($_SESSION['typee'] == ""){
?>
    <a href="index.php"></a>
<?php
 }

//adherent count
$req = $bdd->query("SELECT count(*) as totalAdh FROM adherent " );
$donnees = $req->fetch();
$req->closeCursor();


//formation count
$reeq = $bdd->query("SELECT count(*) as totalForm FROM formation " );
$donneees = $reeq->fetch();
$reeq->closeCursor();

//formation count
$reeeq = $bdd->query("SELECT count(*) as totalIsncr FROM inscription " );
$donneeees = $reeeq->fetch();
$reeeq->closeCursor();



?>

<!doctype html>
<html class="no-js" lang="en">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Accueil Maison des ligues</title>
    <meta name="description" content="Accueil Maison des ligues">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="favicon.ico">

    <link rel="stylesheet" href="vendors/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="vendors/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="vendors/themify-icons/css/themify-icons.css">
    <link rel="stylesheet" href="vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="vendors/selectFX/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="vendors/jqvmap/dist/jqvmap.min.css">


    <link rel="stylesheet" href="assets/css/style.css">

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>

</head>

<body>


    <!-- Left Panel -->

    <aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default">

            <?php include ('menu.php') ;?><!-- /.navbar-collapse -->
        </nav>
    </aside><!-- /#left-panel -->

    <!-- Left Panel -->

    <!-- Right Panel -->
    <div id="right-panel" class="right-panel">

        <!-- Header-->
<?php include('header.php') ?>

        <div class="content mt-3">

            <div class="col-sm-12">
                <div class="alert  alert-success alert-dismissible fade show" role="alert">
                    <span class="badge badge-pill badge-success">MAISON DES LIGUES</span> Bonjour, bienvenue sur le site !
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            </div>

            <div class="col-xl-3 col-lg-6">
                <div class="card">
                    <div class="card-body">
                        <div class="stat-widget-one">
                            <div class="stat-icon dib"><i class="ti-money text-success border-success"></i></div>
                            <div class="stat-content dib">
                                <div class="stat-text">ADHERENTS</div>
                                <div class="stat-digit"><?php echo $donnees['totalAdh']; ?></div>
                            </div>
                        </div>
                        <?php
                        if ($_SESSION['typee'] == 'utilisateur' )
                        {
                      
                        }
                        else {
                        
                        echo '<center><a href="formAjoutAdh.php"><i class="fas fa-plus-square"></i> | Ajouter un adhérent</a></center>';          
                        }
                        ?>
                    </div>
                </div>
            </div>

            <div class="col-xl-3 col-lg-6">
                <div class="card">
                    <div class="card-body">
                        <div class="stat-widget-one">
                            <div class="stat-icon dib"><i class="ti-user text-primary border-primary"></i></div>
                            <div class="stat-content dib">
                                <div class="stat-text">FORMATIONS</div>
                                <div class="stat-digit"><?php echo $donneees['totalForm']; ?></div>
                                <?php
                                if ($_SESSION['typee'] == 'utilisateur' OR $_SESSION['typee'] == 'gestionnaire' )
                                {
                      
                                }
                                else {  
                                    echo '<center><a href="ajoutFormation.php"><i class="fas fa-plus-square"></i> | Ajouter formation </a></center>' ;
                                }
                            ?>           
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-3 col-lg-6">
                <div class="card">
                    <div class="card-body">
                        <div class="stat-widget-one">
                            <div class="stat-icon dib"><i class="ti-layout-grid2 text-warning border-warning"></i></div>
                            <div class="stat-content dib">
                                <div class="stat-text">INSCRITS</div>
                                <div class="stat-digit"><?php echo $donneeees['totalIsncr']; ?></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div> <!-- .content -->
    </div><!-- /#right-panel -->

    <!-- Right Panel -->

    <script src="vendors/jquery/dist/jquery.min.js"></script>
    <script src="vendors/popper.js/dist/umd/popper.min.js"></script>
    <script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="assets/js/main.js"></script>


    <script src="vendors/chart.js/dist/Chart.bundle.min.js"></script>
    <script src="assets/js/dashboard.js"></script>
    <script src="assets/js/widgets.js"></script>
    <script src="vendors/jqvmap/dist/jquery.vmap.min.js"></script>
    <script src="vendors/jqvmap/examples/js/jquery.vmap.sampledata.js"></script>

    <script>
        (function($) {
            "use strict";

            jQuery('#vmap').vectorMap({
                map: 'world_en',
                backgroundColor: null,
                color: '#ffffff',
                hoverOpacity: 0.7,
                selectedColor: '#1de9b6',
                enableZoom: true,
                showTooltip: true,
                values: sample_data,
                scaleColors: ['#1de9b6', '#03a9f5'],
                normalizeFunction: 'polynomial'
            });
        })(jQuery);
    </script>

</body>

</html>
