<?php
include('controlSes.php');
include('configBdd.php');
if ($_SESSION['typee'] == ""){
?>
   <a href="index.php"></a>
<?php
}
	$con = mysqli_connect('localhost','root','');

	if (!$con) 
	{
		echo 'Pas de connexion au serveur';
	}

	if (!mysqli_select_db($con,'maisondesligues'))
	{
		echo 'Pas de base selectionner';
	}

	$nom= $_POST['nomFormation'];
	$sport= $_POST['sport'];
	
	


	$sql = "INSERT INTO formation(nomFormation,nomSport) VALUES ('$nom','$sport')";

	if(!mysqli_query($con,$sql))
	{

		echo 'Votre insertion n\'a pas reussi  !';
		echo mysqli_query($con,$sql);
	}
	else
	{
		echo "<script type='text/javascript'>document.location.replace('tableauBord.php');</script>";		

	}



?>