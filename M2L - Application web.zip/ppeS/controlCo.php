<?php 
if(($_SESSION['typee'] == 'utilisateur')){
    
   echo "Vous n'avez pas accès à cet page !";
   
   exit();
          }

?>