<?php
include('configBdd.php');
include('controlSes.php');
 if ($_SESSION['typee'] == ""){
?>
    <a href="index.php"></a>
<?php
 }

if(isset($_GET['numFormation']) AND !empty($_GET['numFormation'])) {
   $suppr_ad = htmlspecialchars($_GET['numFormation']);
   $suppr = $bdd->prepare('DELETE FROM formation WHERE numFormation = ?');
   $suppr->execute(array($suppr_ad));
   
  	echo 'Nous venons de supprimer cette formation '.$_GET['numFormation'].' ainsi que tous ces informations le concernant.';
    //header('Location: index.php');
}
else {
	echo 'La variable de notre formulaire n\'est pas initialisée.';
}
   

?>