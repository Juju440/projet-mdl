<?php
include('controlSes.php');
include('configBdd.php');
if ($_SESSION['typee'] == ""){
?>
   <a href="index.php"></a>
<?php
}
$con = mysqli_connect('localhost','root','');

	if (!$con) 
	{
		echo 'Pas de connexion au serveur';
	}

	if (!mysqli_select_db($con,'maisondesligues'))
	{
		echo 'Pas de base selectionner';
	}

	$nom= $_POST['nom'];
	$adrRue= $_POST['adrRue'];
	$codePostal= $_POST['codePostal'];
	$ville= $_POST['ville'];
	$mail= $_POST['mail'];
	$mdp= sha1($_POST['mdp']);
	$type= 'utilisateur';
	


	$sql= "INSERT INTO adherent(nom,adrRue,codePostal,ville,mail,mdp) VALUES ('$nom','$adrRue', '$codePostal', '$ville', '$mail','$mdp');";
	
	if(!mysqli_query($con,$sql))
	{

		echo 'Votre insertion n\'a pas reussi  !';
		echo mysqli_multi_query($con,$sql);
	}
	else
	{
		echo "<script type='text/javascript'>document.location.replace('tableauBord.php');</script>";		

	}



?>