<?php
include('configBdd.php');
include('controlSes.php');
 if ($_SESSION['typee'] == ""){
?>
    <a href="index.php"></a>
<?php
 }

if(isset($_GET['numInscription']) AND !empty($_GET['numInscription'])) {
   $suppr_ad = htmlspecialchars($_GET['numInscription']);
   $suppr = $bdd->prepare('DELETE FROM inscription WHERE numInscription = ?');
   $suppr->execute(array($suppr_ad));
   
  	echo 'Nous venons de supprimer l\'inscription de l\'adherent numéro'.$_GET['numInscription'].' ainsi que tous les informations le concernant.';
    //header('Location: index.php');
}
else {
	echo 'La variable de notre formulaire n\'est pas initialisée.';
}
   

?>