<?php
include('controlSes.php');
include('configBdd.php');
if ($_SESSION['typee'] == ""){
?>
   <a href="index.php"></a>
<?php
}
	$con = mysqli_connect('localhost','root','');

	if (!$con) 
	{
		echo 'Pas de connexion au serveur';
	}

	if (!mysqli_select_db($con,'maisondesligues'))
	{
		echo 'Pas de base selectionner';
	}

	$nom= $_POST['nom'];
	$prenom= $_POST['prenom'];
	$dateNaiss= $_POST['dateNaiss'];
	$mail= $_POST['mail'];
	$nomFormation= $_POST['nomFormation'];
	$sport= $_POST['sport'];

	
	$sql = "INSERT INTO inscription(numAdherent,nom,prenom,dateNaiss,mail,nomFormation,sport) VALUES ('$nom','$prenom', '$dateNaiss', '$mail', '$nomFormation', '$sport')";

	if(!mysqli_query($con,$sql))
	{

		echo 'Votre insertion n\'a pas reussi  !';
		echo mysqli_query($con,$sql);
	}
	else
	{
		echo "<script type='text/javascript'>document.location.replace('tableauBord.php');</script>";		

	}



?>