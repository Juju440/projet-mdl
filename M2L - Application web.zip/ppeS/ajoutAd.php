<?php
include('controlSes.php');
if ($_SESSION['typee'] == ""){
?>
   <a href="index.php"></a>
<?php
}
include('header.php');

include('configBdd.php');

if(isset($_POST['submit']))
{
if(!empty($_POST['nomAdh']) AND !empty($_POST['prenomAdh']) AND !empty($_POST['level']) AND !empty($_POST['name']) AND !empty($_POST['nomLigue']) AND !empty($_POST['adrRue'])AND !empty($_POST['codePostal'])AND !empty($_POST['ville'])AND !empty($_POST['mail'])AND !empty($_POST['motdepasse']))
    {
        $requete = $bdd->prepare("INSERT adherent(nomAdh, prenomAdh,level,name,nomLigue,adrRue,codePostal,Ville,mail,motdepasse) VALUES(?,?,?,?,?,?,?,?,?,?)");

        $requete->execute(array($_POST['nomAdh'],$_POST['prenomAdh'],$_POST['level'],$_POST['name'],$_POST['nomLigue'],$_POST['adrRue'],$_POST['codePostal'],$_POST['ville'],$_POST['mail'],$_POST['motdepasse']));

        $erreur="Confirmation du traitement.";

    }else{
    
    $erreur="Champs vide.";
}
   
}
?>

<html>
<body>
    
    <br>
<div class="container">
<h2>Ajout d'un adhérent:</h2>
<br>
<form action="" method="POST">

<label>Nom:</label>
<input type="text" class="form-control" name="nomAdh">
<br>
<label>Prénom:</label>
<input type="text" class="form-control" name="prenomAdh">
<br>
<label>Niveau:</label>
<input type="text" class="form-control" name="level">
<br>
<label>rôle:</label>
<input type="text" class="form-control" name="name">
<br>
<label>Nom ligue:</label>
<input type="text" class="form-control" name="nomLigue">
<br>
<label>Adresse rue:</label>
<input type="text" class="form-control" name="adrRue">
<br>
<label>Code Postal:</label>
<input type="text" class="form-control" name="codePostal">
<br>
<label>Ville:</label>
<input type="text" class="form-control" name="ville">
<br>
<label>E-mail:</label>
<input type="email" class="form-control" name="mail">
<br>
<label>Mot de passe:</label>
<input type="password" class="form-control" name="motdepasse">
<br>
<button type="submit" name="submit" class="btn btn-primary">Valider l'inscription</button>
</form>
</div>
<?php if(isset($erreur)) { echo $erreur; } ?>
</body>
</html>