<?php 
include('configBdd.php');
include('controlSes.php');
 if ($_SESSION['typee'] == ""){
?>
    <a href="index.php"></a>
<?php
 }


if (isset($_POST['numAdherent'])) {

      $id = $_POST['numAdherent'];
	  $nom = $_POST['nom'];
      $adrRue = $_POST['adrRue'];
      $codePostal = $_POST['codePostal'];
      $ville = $_POST['ville'];
      $mail = $_POST['mail'];


    mysql_query("UPDATE adherent nom = $nom , adrRue = $adrRue, codePostal = $codePostal, ville = $ville, mail = $mail  WHERE numAdherent = $id");
}

header( 'Location: index.php' ) ;

?>