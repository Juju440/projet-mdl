<?php 

include('configBdd.php');
include('controlSes.php');
 if ($_SESSION['typee'] == ""){
?>
    <a href="index.php"></a>
<?php
 } 
if(isset($_GET['numAdherent']) AND !empty($_GET['numAdherent']))
{
    $modifAdh = $bdd->prepare("SELECT * FROM adherent WHERE numAdherent = ?");
    $modifAdh->execute(array($_GET['numAdherent']));
    $adherent = $modifAdh->fetch();
    
}
?>

<?php
        //Si et seulement si le bouton submit est appuyé.
    if(isset($_POST['submit_adherent'])) {
        //si et seulement si les champs suivant sont remplit donc non vide ==>
        if(isset($_POST['nom'],$_POST['adrRue']) AND !empty($_POST['codePostal']) AND !empty($_POST['ville']) AND !empty($_POST['mail']) AND !empty($_POST['mdp'])) {
        //securisation des chaines de caracteres (htmlspecialchars)
             $adhr_id = htmlspecialchars($_GET['numAdherent']);
             $nom = htmlspecialchars($_POST['nom']);             
             $adrRue = htmlspecialchars($_POST['adrRue']);
             $codePostal = htmlspecialchars($_POST['codePostal']);
             $ville = htmlspecialchars($_POST['ville']);
             $mail = htmlspecialchars($_POST['mail']);
             $mdp = htmlspecialchars($_POST['mdp']);

                //requete sql pour l'update
             $update = $bdd->prepare('UPDATE adherent SET nom= ?,adrRue  = ?,codePostal  = ?,ville  = ?,mail = ?, mdp= ? WHERE numAdherent = ?');
            
                //execution de la requete en mettant en paramètre (array) les variables suivant
             $update->execute(array($nom,$adrRue,$codePostal,$ville,$mail,$mdp,$adhr_id));
            
             //si la modification à réussi il affichera ça (si pas de redirection mais tu devras actualiser tout de mm)
             $message = "<p style='color:green;'>Votre adherent a bien été mis à jour !</p>";
            //si la modif réussi il va te rediriger sur la page avec l'id qui correspond
             header('Location: http://127.0.0.1/ppeS/modifAdherent.php?numAdherent='.$adhr_id);


          } //si la modif ne réussi pas il affichera un message d'erreur
            else {
                   $message = "<p style='color: red;'>Veuillez remplir tous les champs</p>";
                 }
          }

?>





<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="en">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Modifier un adhérent</title>
    <meta name="description" content="Sufee Admin - HTML5 Admin Template">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="favicon.ico">


    <link rel="stylesheet" href="vendors/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="vendors/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="vendors/themify-icons/css/themify-icons.css">
    <link rel="stylesheet" href="vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="vendors/selectFX/css/cs-skin-elastic.css">

    <link rel="stylesheet" href="assets/css/style.css">

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>



</head>

<body>
    <!-- Left Panel -->

   
 <aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default">
        <?php include('menu.php'); ?>
        </nav>
    </aside><!-- /#left-panel -->

    <!-- Left Panel -->

    <!-- Right Panel -->

    <div id="right-panel" class="right-panel">

        <!-- Header-->
<?php include ('header.php'); ?><!-- /header -->
        <div class="content mt-3">
            <div class="animated fadeIn">
                           <div class="col-lg-6">
                                <div class="card">
							<div class="card-header">Modifer un adherent</div>
								<div class="card-body card-block">
    	<form action="" method="post">
       		<div class="form-group">
            <div class="input-group">
                <input  class="form-control" type="text" id="username2" name="nom" value="<?php echo $adherent["nom"];?>" >
                <div class="input-group-addon"><i class="fa fa-user"></i></div>
            </div>
            </div>


        <div class="form-group">
            <div class="input-group">
                <input class="form-control" type="text" id="username2" name="adrRue" value="<?php echo $adherent["adrRue"];?>" >
                <div class="input-group-addon"><i class="fa fa-user"></i></div>
            </div>
        </div>
        
        
         <div class="form-group">
            <div class="input-group">
                <input class="form-control" type="text" id="username2" name="codePostal" value="<?php echo $adherent["codePostal"];?>">
                <div class="input-group-addon"><i class="fa fa-user"></i></div>
            </div>
         </div>
         
        <div class="form-group">
            <div class="input-group">
                <input class="form-control" type="text" id="username2" name="ville" value="<?php echo $adherent["ville"];?>" >
                <div class="input-group-addon"><i class="fa fa-asterisk"></i></div>
            </div>
        </div>
        
        
        <div class="form-group">
            <div class="input-group">
                <input class="form-control" type="email" id="password2" name="mail" value="<?php echo $adherent["mail"];?>" >
                <div class="input-group-addon"><i class=" fa fa-envelope "></i></div>
            </div>
        </div>
               
        <div class="form-group">
            <div class="input-group">
                <input  class="form-control" type="text" id="password2" name="mdp" value="<?php echo $adherent["mdp"];?>" >
                <div class="input-group-addon"><i class="fa fa-user"></i></div>
            </div>
            </div>      
            <button type="submit" name="submit_adherent" class="btn btn-secondary btn-sm">Valider</button>
            </form>
            <?php //code pour afficher les msg d'erreurs.
                                    if(isset($message)) { echo $message; } ?>
            
        
    </div>
</div> 
                                              
                                </div>
                            </div><!-- .animated -->
                        </div><!-- .content -->
                                <!-- Right Panel -->


        <script src="vendors/jquery/dist/jquery.min.js"></script>
        <script src="vendors/popper.js/dist/umd/popper.min.js"></script>

        <script src="vendors/jquery-validation/dist/jquery.validate.min.js"></script>
        <script src="vendors/jquery-validation-unobtrusive/dist/jquery.validate.unobtrusive.min.js"></script>

        <script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>
        <script src="assets/js/main.js"></script>
</body>
</html>
