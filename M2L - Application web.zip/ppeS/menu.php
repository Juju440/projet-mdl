<div class="navbar-header">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#main-menu" aria-controls="main-menu" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand" href="./"><img src="images/imagess.jpg" alt="Logo"></a>
                <a class="navbar-brand hidden" href="./"><img src="images/logo2.png" alt="Logo"></a>
            </div>

            <div id="main-menu" class="main-menu collapse navbar-collapse">
                <ul class="nav navbar-nav">
                    <menu class='active'>
                        <a href="tableauBord.php"> <i class="menu-icon fa fa-dashboard"></i> Accueil </a>
                    </menu>
                    
                    <?php
                    if ($_SESSION['typee'] == 'utilisateur'  )
                         {
                                    
                            }
                    else {  
                    ?>
                        <menu class='active'>
                    <?php
                        echo'<a href="adherent.php"> <i class="fa fa-table"></i> Liste des adherents </a>';
                        ?>
                        </menu>
                    <?php
                    }
                    ?>
                    
                    <menu class='active'>
                        <a href="formation.php"> <i class="fa fa-table"></i> Liste des Formations </a>
                    </menu>
                    
                    
                      <?php
                    if ($_SESSION['typee'] == 'utilisateur' OR $_SESSION['typee'] == 'gestionnaire' )
                        {
                        
                        }
                    else {       
                    ?>
                        <menu class='active'>
                    <?php            
                        echo'<a href="tableauInscription.php"> <i class="fa fa-table"></i> Liste des adhérents inscrit à une formation </a>';
                    ?>    
                        </menu>
                    <?php
                    }
                    ?>
                   
                    <menu class='active'>
                        <a href="inscription.php"> <i class="fa fa-table"></i> S'inscrire à une formation </a>
                    </menu>

                    
                    

                   <!--<h3 class="menu-title">Extras</h3> 
                    <li class="menu-item-has-children dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-glass"></i>Pages</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="menu-icon fa fa-sign-in"></i><a href="page-login.html">Se connecter</a></li>
                            <li><i class="menu-icon fa fa-sign-in"></i><a href="page-register.html">Register</a></li>
                            <li><i class="menu-icon fa fa-paper-plane"></i><a href="pages-forget.html">Forget Pass</a></li>
                        </ul>
                    </li> !--> 
                </ul>
            </div>  