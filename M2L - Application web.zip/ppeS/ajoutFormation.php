<?php
include('configBdd.php');
include('controlSes.php');
 if ($_SESSION['typee'] == ""){
?>
    <a href="index.php"></a>
<?php
 }
 ?>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Ajout formation</title>
    <meta name="description" content="Maison des ligues">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="favicon.ico">


    <link rel="stylesheet" href="vendors/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="vendors/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="vendors/themify-icons/css/themify-icons.css">
    <link rel="stylesheet" href="vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="vendors/selectFX/css/cs-skin-elastic.css">

    <link rel="stylesheet" href="assets/css/style.css">

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>



</head>

<body>
    <!-- Left Panel -->

   
 <aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default">
        <?php include('menu.php'); ?>
        </nav>
    </aside><!-- /#left-panel -->

    <!-- Left Panel -->

    <!-- Right Panel -->

    <div id="right-panel" class="right-panel">

        <!-- Header-->
<?php include ('header.php'); ?><!-- /header -->

            <?php //code pour afficher les msg d'erreurs.
                                    if(isset($message)) { echo $message; } ?>

<div class="content mt-3">
            <div class="animated fadeIn">
                           <div class="col-lg-6">
                                <div class="card">
							<center><div  class="card-header"><h1><h2>Ajouter une nouvelle formation</h2></h1></div></center>
								<div class="card-body card-block">

	<form action="insertForm.php" method="post">

        <label> Nom de la formation :</label> <input type="text" class="form-control" name="nomFormation"><br><br>

        <label> Nom du sport concerné :</label> <input type="text" class="form-control" name="sport"><br><br>
        
        
		<center><input type="submit" class="btn btn-success" value="Valider"></center>
	</form>
</div>
</div>

        <script src="vendors/jquery/dist/jquery.min.js"></script>
        <script src="vendors/popper.js/dist/umd/popper.min.js"></script>

        <script src="vendors/jquery-validation/dist/jquery.validate.min.js"></script>
        <script src="vendors/jquery-validation-unobtrusive/dist/jquery.validate.unobtrusive.min.js"></script>

        <script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>
        <script src="assets/js/main.js"></script>
</body>
</html>

