<?php
include('configBdd.php');
include('controlSes.php');
 if ($_SESSION['typee'] == ""){
?>
    <a href="index.php"></a>
<?php
 }

if(isset($_GET['numAdherent']) AND !empty($_GET['numAdherent'])) {
   $suppr_ad = htmlspecialchars($_GET['numAdherent']);
   $suppr = $bdd->prepare('DELETE FROM adherent WHERE numAdherent = ?');
   $suppr->execute(array($suppr_ad));
   
  	echo 'Nous venons de supprimer cet adherent '.$_GET['numAdherent'].' ainsi que tous ces informations le concernant.';
    //header('Location: index.php');
}
else {
	echo 'La variable de notre formulaire n\'est pas initialisée.';
}
   

?>