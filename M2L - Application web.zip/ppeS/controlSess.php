<?php

if ($_SESSION['type'] == '' )
                        {
                            ?>       <a href="formAjoutAdh.php"></a>
                       <?php }?>
                        