-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le :  ven. 03 mai 2019 à 21:36
-- Version du serveur :  10.1.36-MariaDB
-- Version de PHP :  5.6.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `maisondesligues`
--

-- --------------------------------------------------------

--
-- Structure de la table `adherent`
--

CREATE TABLE `adherent` (
  `numAdherent` int(11) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `adrRue` varchar(255) NOT NULL,
  `codePostal` int(11) NOT NULL,
  `ville` varchar(255) NOT NULL,
  `mail` varchar(255) NOT NULL,
  `numLigue` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Table Adherent';

--
-- Déchargement des données de la table `adherent`
--

INSERT INTO `adherent` (`numAdherent`, `nom`, `adrRue`, `codePostal`, `ville`, `mail`, `numLigue`) VALUES
(1, 'JoelMMMM', '120 avenie R', 97440, 'Malloyyy', 'Joel@gmail.com', 0),
(2, 'David', '130 avenue B', 97445, 'madruisz', 'David@gmail.com', 0),
(3, 'Claudiine', '10 avenue Z', 97424, 'miz', 'Claude@gmail.com', 0),
(4, 'Charles', '25 avenue F', 95214, 'maz', 'Charles@gmail.com', 0),
(5, 'Sonia', '562 avenue S', 97463, 'Grand Anses', 'Soni@gmail.com', 0),
(6, 'Romain', '2 avenue N', 97484, 'Saint Denis', 'Romain@gmail.com', 0),
(7, 'Ludo', '854 avenue Y', 97421, 'Saint Rose', 'Ludo@gmail.com', 0),
(8, 'Fabio', '14 Chemin Bassin Bleu', 97414, 'St-Gilles', 'Fabio@gmail.com', 0),
(9, 'Platine', '104 avenue O', 97412, 'mero', 'tars@gmail.com', 0),
(10, 'Bronze', '116 rue de la mer', 97440, 'St-Andre', 'andre@gmail.com', 0);

-- --------------------------------------------------------

--
-- Structure de la table `formation`
--

CREATE TABLE `formation` (
  `numFormation` int(11) NOT NULL,
  `libelle` varchar(255) NOT NULL,
  `nbCredit` int(11) NOT NULL,
  `numTypeFormation` int(11) NOT NULL,
  `numNiveauFormation` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `formation`
--

INSERT INTO `formation` (`numFormation`, `libelle`, `nbCredit`, `numTypeFormation`, `numNiveauFormation`) VALUES
(1, 'Basket-ball', 100, 542, 2),
(2, 'Football', 50, 654, 1),
(3, 'Handball', 100, 582, 2),
(4, 'Tennis', 100, 753, 2),
(5, 'Volley-ball', 100, 951, 2),
(6, 'Hockey', 150, 197, 3),
(7, 'Baseball', 50, 985, 1),
(8, 'Boxe', 50, 975, 1),
(9, 'Natation', 50, 145, 1),
(10, 'Escalade', 100, 523, 2);

-- --------------------------------------------------------

--
-- Structure de la table `inscription`
--

CREATE TABLE `inscription` (
  `numFormation` int(11) NOT NULL,
  `numSession` int(11) NOT NULL,
  `numAdherent` int(11) NOT NULL,
  `nbStagiaire` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `inscription`
--

INSERT INTO `inscription` (`numFormation`, `numSession`, `numAdherent`, `nbStagiaire`) VALUES
(1, 1, 1, 1),
(1, 2, 2, 1),
(3, 3, 3, 1),
(4, 4, 4, 1),
(5, 5, 5, 1),
(6, 6, 6, 1),
(7, 7, 7, 1),
(8, 8, 8, 1),
(9, 9, 9, 1),
(10, 10, 10, 1);

-- --------------------------------------------------------

--
-- Structure de la table `ligue`
--

CREATE TABLE `ligue` (
  `numLigue` int(11) NOT NULL,
  `nomLigue` varchar(255) NOT NULL,
  `telephone` int(11) NOT NULL,
  `mail` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `ligue`
--

INSERT INTO `ligue` (`numLigue`, `nomLigue`, `telephone`, `mail`) VALUES
(1, 'PSG', 693225684, 'psg@gmail.com'),
(2, 'Real Madrid', 692556677, 'real@real.com'),
(3, 'Lyon', 692859674, 'lyon@outlook.com'),
(4, 'Manchester United', 692446633, 'm.united@hotmail.fr'),
(5, 'Guingamp', 62554466, 'guingamp@outlook.com'),
(6, 'Arsenal', 62996633, 'arsenal@gmail.com'),
(7, 'Nantes', 692446633, 'nantes@gmail.com'),
(8, 'Juventus', 692112233, 'juv@outlook.com'),
(9, 'FC Barcelone', 692666112, 'barca@barca.fr'),
(10, 'Angers', 692587412, 'angers@hotmail.com'),
(11, 'Lille', 692333345, 'lille@laposte.net'),
(12, 'Manchester City', 692458596, 'manchester.city@laposte.net'),
(13, 'Valence', 692548596, 'valence52@gmail.com'),
(14, 'Monaco', 692004525, 'monaco10@hotmail.com'),
(15, 'Marseille', 692000001, 'marseille0@outlook.fr');

-- --------------------------------------------------------

--
-- Structure de la table `niveauformation`
--

CREATE TABLE `niveauformation` (
  `numNiveauFormation` int(11) NOT NULL,
  `libelle` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `niveauformation`
--

INSERT INTO `niveauformation` (`numNiveauFormation`, `libelle`) VALUES
(1, 'Informatique\r\n'),
(2, 'Cuisine'),
(3, 'Boulangerie'),
(4, 'Pâtisser'),
(5, 'Boucherie'),
(6, 'Carreleur'),
(7, 'Plombier'),
(8, 'veterinaire'),
(9, 'Professeur'),
(10, 'Ingenieur');

-- --------------------------------------------------------

--
-- Structure de la table `session`
--

CREATE TABLE `session` (
  `numFormation` int(11) NOT NULL,
  `numSession` int(11) NOT NULL,
  `dateDebut` date NOT NULL,
  `dateFin` date NOT NULL,
  `placesMax` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `session`
--

INSERT INTO `session` (`numFormation`, `numSession`, `dateDebut`, `dateFin`, `placesMax`) VALUES
(1, 1, '2018-11-14', '2018-11-15', 30),
(1, 2, '2018-11-15', '2018-11-16', 30),
(3, 3, '2018-11-16', '2018-11-17', 30),
(4, 4, '2018-11-17', '2018-11-18', 30),
(5, 5, '2018-11-18', '2018-11-19', 30),
(6, 6, '2018-11-19', '2018-11-20', 30),
(7, 7, '2018-11-20', '2018-11-21', 30),
(8, 8, '2018-11-21', '2018-11-22', 30),
(9, 9, '2018-11-22', '2018-11-23', 30),
(10, 10, '2018-11-23', '2018-11-24', 30);

-- --------------------------------------------------------

--
-- Structure de la table `stagiaire`
--

CREATE TABLE `stagiaire` (
  `id` int(11) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `prenom` varchar(255) NOT NULL,
  `numFormation` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `typeformation`
--

CREATE TABLE `typeformation` (
  `numTypeFormation` int(11) NOT NULL,
  `libelle` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `typeformation`
--

INSERT INTO `typeformation` (`numTypeFormation`, `libelle`) VALUES
(542, 'Type1'),
(654, 'Type2'),
(582, 'Type3'),
(753, 'Type4'),
(951, 'Type5'),
(197, 'Type6'),
(985, 'Type7'),
(975, 'Type8'),
(145, 'Type9'),
(523, 'Type10');

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `nom_user` varchar(255) NOT NULL,
  `mail` varchar(255) NOT NULL,
  `mdp` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `user`
--

INSERT INTO `user` (`id`, `nom_user`, `mail`, `mdp`, `type`) VALUES
(1, 'admin', 'admin@gmail.com', 'admin', 'administrateur'),
(2, 'user', 'user@gmail.com', 'user12345', 'utilisateur'),
(3, 'gestionnaire', 'gestion.formation@gmail.com', 'gestion3', 'gestionnaire');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `adherent`
--
ALTER TABLE `adherent`
  ADD PRIMARY KEY (`numAdherent`);

--
-- Index pour la table `formation`
--
ALTER TABLE `formation`
  ADD PRIMARY KEY (`numFormation`),
  ADD KEY `formation_fk_1` (`numTypeFormation`),
  ADD KEY `formation_fk_2` (`numNiveauFormation`);

--
-- Index pour la table `inscription`
--
ALTER TABLE `inscription`
  ADD PRIMARY KEY (`numFormation`,`numSession`),
  ADD KEY `formation_fk_1` (`numFormation`),
  ADD KEY `formation_fk_2` (`numSession`),
  ADD KEY `formation_fk_3` (`numAdherent`),
  ADD KEY `inscription_fk_1` (`numFormation`),
  ADD KEY `inscription_fk_2` (`numSession`),
  ADD KEY `inscription_fk_3` (`numAdherent`);

--
-- Index pour la table `ligue`
--
ALTER TABLE `ligue`
  ADD PRIMARY KEY (`numLigue`);

--
-- Index pour la table `niveauformation`
--
ALTER TABLE `niveauformation`
  ADD PRIMARY KEY (`numNiveauFormation`);

--
-- Index pour la table `session`
--
ALTER TABLE `session`
  ADD PRIMARY KEY (`numFormation`,`numSession`),
  ADD KEY `session_fk_1` (`numFormation`),
  ADD KEY `session_fk_2` (`numFormation`);

--
-- Index pour la table `stagiaire`
--
ALTER TABLE `stagiaire`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `typeformation`
--
ALTER TABLE `typeformation`
  ADD PRIMARY KEY (`libelle`);

--
-- Index pour la table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `ligue`
--
ALTER TABLE `ligue`
  MODIFY `numLigue` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT pour la table `stagiaire`
--
ALTER TABLE `stagiaire`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
