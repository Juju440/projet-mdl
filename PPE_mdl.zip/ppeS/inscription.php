<?php

// Testons si le fichier a bien été envoyé et s'il n'y a pas d'erreur

if (isset($_FILES['monfichier']) AND $_FILES['monfichier']['error'] == 0)

{

        // Testons si le fichier n'est pas trop gros

        if ($_FILES['monfichier']['size'] <= 1000000)

        {

                // Testons si l'extension est autorisée

                $infosfichier = pathinfo($_FILES['monfichier']['name']);

                $extension_upload = $infosfichier['extension'];

                $extensions_autorisees = array('doc', 'docx', 'pdf', 'jpeg','png');

                if (in_array($extension_upload, $extensions_autorisees))

                {

                        // On peut valider le fichier et le stocker définitivement

                        move_uploaded_file($_FILES['monfichier']['tmp_name'], 'uploads/' . basename($_FILES['monfichier']['name']));

                        echo "L'envoi a bien été effectué !";

                }

        }

}
?>

<?php 

if(isset($_GET['Post']))
{
    include('config.php');
    $req = $bdd->prepare('SELECT * FROM typeformation INNER JOIN formation ON typeformation.numFormation = formation.numFormation WHERE typeformation.nomFormation = ?');
    $req->execute(array($_GET['Post']));
    $postule = $req->fetch();
    

?>



<head>
<style>
legend {
    background-color: #000;
    color: #fff;
    padding: 3px 6px;
}

.output {
    font: 1rem 'Fira Sans', sans-serif;
}

label {
    margin-top: 1rem;
    display: block;
    font-size: .8rem;
}
    

    
</style>

</head>

<fieldset>
    
<legend>Demande</legend>
    
<form action="Demandeformation.php" method="post" enctype="multipart/form-data">

    
    <label title="">Formation demandé :</label>
    <input type="text" name="nomFormation" value="<?php echo $postule['nomFormation'];?>">
<br>
<br>
    
    <label title="">Nom/Prenom:</label>
    <input type="text" name="" value="Demandeur">
    
<br>
<br>


<br>


<br>
<br>
    
                        <input type="submit" value="Soumettre">

</form>

</fieldset>
<?php } ?>