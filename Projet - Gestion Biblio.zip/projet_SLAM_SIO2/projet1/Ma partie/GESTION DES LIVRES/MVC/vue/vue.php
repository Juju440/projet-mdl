<html>
	<head>
			<meta charset="utf-8" />

			<title> Affichage de tous les livres </title>
	</head>
<body>
<?php
$base = new GestionBaseLivres($db);
$livres=$base->afficherTousLivres();
echo '</br>';
echo ' Le titre du livre numéro ' ,$num, ' est ', $livres->getTitre(), ' son prix est de ', $livres->getPrix(), ' euros';
echo '</br>';
?>
<table cellpadding="10" cellspacing="1" border="2">
	<tr>
      <th align="center">Titre</th>
      <th align="center">Prix</th>
      <th align="center">numéro</th>
   </tr>
<?
foreach($livres as $lvr) //parcours la collection des livres
	{
	?>
	<tr>
		<td align="center">
			<?
				echo $lvr->getTitre();//affiche le titre de tous les livres 
			?>
		</td>
		<td align="center">
			<?
				echo $lvr->getPrix();//affiche le prix de tous les livres 	
			?>
		</td>
		<td align="center">
			<?
				echo $lvr->getNum();//affiche le numéro de tous les livres 
			?>
		</td>
	</tr>
	<?
	}
?>
</table>
</center>
</body>
</html>