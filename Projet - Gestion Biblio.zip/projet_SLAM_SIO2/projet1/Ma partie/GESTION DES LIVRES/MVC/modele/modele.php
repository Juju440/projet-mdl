<?php

class livre
{
	private $_num;
  private $_isbn;
  private $_titre;
  private $_prix;
  private $_editeur;
  private $_annee;
  private $_langue;
  private $_numAuteur;
  private $_numGenre;
    
  public function __construct($donnees) // Constructeur demandant 2 paramètres
  {
    $this->hydrate2($donnees); //le constructeur appelle la fonction d'hydratation qui va initialiser les attributs avec les valeurs de la base
  } 
  
  public function hydrate2(array $donnees) // permet de gérer une modification des attributs de l'objet sans changer la méthode d'hydratation
  {
      foreach ($donnees as $key => $value) //recupère chaque cellule du tableau
      {
        $method = 'set'.ucfirst($key);//positionne la bonne méthode, avec une majuscule à la première lettre 
        if (method_exists($this, $method))
        {
          $this->$method($value);//appelle la bonne méthode setter
        }
      }
  }

    
  public function setPrix($_prix)
  {
	 if(is_int($_prix))
	 {
    $this->$_prix=$prix;
	 }
	 else
	 {
    echo "Ce n'est pas le bon type de valeur";
	 }
  }
    
  public function getNum()
  {
    return $this->_num;
  }

  public function getIsbn()
  {
    return $this->_isbn;
  }

  public function getTitre()
  {
    return $this->_titre;
  }

  public function getPrix()
  {
    return $this->_prix;
  }
    
  public function getEditeur()
  {
    return $this->_editeur;
  }

  public function getAnnee()
  {
    return $this->_annee;
  }
    
  public function getNumAuteur()
  { 
    return $this->_numAuteur;
  }

  public function getNumGenre()
  {
    return $this->_numGenre;
  }


  class GestionBaseLivres
  {

    private $_Mabase; // Instance de la base de données


    public function __construct($Mabase) //constructeur de la classe
    {
      $this->setDb($Mabase);
    }
  
  
    public function setDb(PDO $Mabase) //setter de l'attribut base
    {
      $this->_db = $Mabase;
    }
  

    public function afficherLivre($num)
    {
      $num = (int) $num;

      $q = $this->_db->query('SELECT num, titre, prix FROM livre WHERE num = '.$num);
      $donnees = $q->fetch(PDO::FETCH_ASSOC);
      return new Livre($donnees);
    }

    public function afficherTousLivres()
    {
      $adherents = [];

      $q = $this->_db->query('SELECT num, titre, prix FROM livre order by titre');

      while ($donnees = $q->fetch(PDO::FETCH_ASSOC))
      {
        $livres[] = new livre($donnees);
      }

      return $livres;//retourne la collection de tous les adherents de la base
    }
  }

  try
{
$db = new PDO('mysql:host=localhost;dbname=biblio2016','test' ,'' );
}
catch (Exception $e)
{
die('Erreur : ' . $e->getMessage());
}
print("connexion base biblio OK</br>");

