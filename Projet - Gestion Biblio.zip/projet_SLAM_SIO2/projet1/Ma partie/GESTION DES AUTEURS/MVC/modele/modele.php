<?php

class livre
{
  private $_num;
  private $_nom;
  private $_prenom;
  private $_nationalite;
    
  public function __construct($donnees) // Constructeur demandant 2 paramètres
  {
    $this->hydrate2($donnees); //le constructeur appelle la fonction d'hydratation qui va initialiser les attributs avec les valeurs de la base
  } 
  
  public function hydrate2(array $donnees) // permet de gérer une modification des attributs de l'objet sans changer la méthode d'hydratation
  {
    foreach ($donnees as $key => $value) //recupère chaque cellule du tableau
    {
      $method = 'set'.ucfirst($key);//positionne la bonne méthode, avec une majuscule à la première lettre 
      if (method_exists($this, $method))
      {
        $this->$method($value);//appelle la bonne méthode setter
      }
    }
  }

    
    public function getNum()
    {
        return $this->_num;
    }

    public function getNom()
    {
        return $this->_nom;
    }

    public function getPrenom()
    {
        return $this->_prenom;
    }

    public function getNationalite()
    {
        return $this->_nationalite;
    }


      class GestionBaseAuteurs

{

  private $_Mabase; // Instance de la base de données


  public function __construct($Mabase) //constructeur de la classe

  {
    $this->setDb($Mabase);
  }
  
  
  public function setDb(PDO $Mabase) //setter de l'attribut base
  {
    $this->_db = $Mabase;
  }
  

  public function getAuteur($num)
  {
    $num = (int) $num;

    $q = $this->_db->query('SELECT num, nom, prenom, nationalite FROM auteur WHERE num = '.$num);
    $donnees = $q->fetch(PDO::FETCH_ASSOC);
    return new auteur($donnees);
  }

public function afficherTousAuteurs()
  {
   $adherents = [];

    $q = $this->_db->query('SELECT num, nom, prenom, nationalite FROM auteur order by nom');

    while ($donnees = $q->fetch(PDO::FETCH_ASSOC))
    {
      $auteurs[] = new auteur($donnees);
    }

    return $auteurs;//retourne la collection de tous les auteurs de la base
  }


  public function rechercheAuteur()
  {

  }

  try
{
$db = new PDO('mysql:host=localhost;dbname=biblio2016','test' ,'' );
}
catch (Exception $e)
{
die('Erreur : ' . $e->getMessage());
}
print("connexion base biblio OK</br>");

