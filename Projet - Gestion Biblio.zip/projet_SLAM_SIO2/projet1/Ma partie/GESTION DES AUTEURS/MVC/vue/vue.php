<html>
	<head>
			<meta charset="utf-8" />

			<title> Affichage de tous les auteurs </title>
	</head>
<body>
<?php
$base = new GestionBaseAuteurs($db);
$auteurs=$base->afficherTousAuteurs();
echo '</br>';
echo ' Le nom de lauteur numéro ' ,$num, ' est ', $auteurs->getNom(), ' son prenom est ', $auteurs->getPrenom(), 'sa nationalité est ', $auteurs->getNationalite();
echo '</br>';
?>
<table cellpadding="10" cellspacing="1" border="2">
	<tr>
      <th align="center">Nom</th>
      <th align="center">Prénom</th>
      <th align="center">numéro</th>
      <th align="center">Nationalité</th>
   </tr>
<?
foreach($auteurs as $a) //parcours la collection des auteurs
	{
	?>
	<tr>
		<td align="center">
			<?
				echo $a->getNom();//affiche le nom des auteurs 
			?>
		</td>
		<td align="center">
			<?
				echo $a->getPrenom();//affiche le prénom des auteurs	
			?>
		</td>
		<td align="center">
			<?
				echo $a->getNum();//affiche le numéro des auteurs 
			?>
		</td>
		<td align="center">
			<?
				echo $a->getNationalite();//affiche la nationalité des auteurs
	</tr>
	<?
	}
?>
</table>
</center>
</body>
</html>