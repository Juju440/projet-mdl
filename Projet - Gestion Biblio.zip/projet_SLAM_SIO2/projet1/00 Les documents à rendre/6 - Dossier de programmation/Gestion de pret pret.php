 <?php
$mysqli = new mysqli('127.0.0.1', 'root', '', '');
if ($mysqli->connect_error) {
    die('Connect Error (' . $mysqli->connect_errno . ') '
            . $mysqli->connect_error);
}
echo '<p>Connection OK '. $mysqli->host_info.'</p>';
echo '<p>Server '.$mysqli->server_info.'</p>';
$mysqli->close();
//connection a la base de donner
?>

<!DOCTYPE html>
<html> <head>
<meta charset="utf-8" />
<title>ajout produit</title> </head>
<body>
<?php

class Pret
{
	private $_id
	private $_datePret
	private $_dateDeRetour
	private $_dateDeRetourReel
	private $_idLivre
	private $_idExemplaire
	private $_idAdherent
}
public function __construct($Mabase)
 
 {
    $this->setDb($Mabase);
 }

public function setDb(PDO $Mabase) //setter de l'attribut base
  {
    $this->_db = $Mabase;
  }

public function emprunter($_idAdherent,$_idExemplaire,$_idLivre,$_dateDeRetourReel,$_dateDeRetour,$_datePret,$_id)

  {
    $req = $this->_db->prepare('INSERT INTO produit(id_adherent,id_exemplaire,id_livre,date_de_retour_reel,date_de_retour,date_pret,id) VALUES(:idaAdherent,:idExemplaire,:idLivre,:dateDeRetourReel,:dateDeRetour,:datePret,:id)');
	$req->bindValue(':idAdherent', $idAdherent);
	$req->bindValue(':idExemplaire', $idExemplaire);
	$req->bindValue(':idLivre', $idLivre);
	$req->bindValue(':dateDeRetourReel', $dateDeRetourReel);
	$req->bindValue(':dateDeRetour', $dateDeRetour);
	$req->bindValue(':datePret', $datePret);
	$req->bindValue(':id', $id);

	$req->execute();
  }

public function rendre($dateDeRetourReel)
	{
		 $req = $this->_db->prepare('INSERT INTO produit(date_de_retour_reel) VALUES(:dateDeRetourReel)');
		 $req->bindValue(':dateDeRetourReel', $dateDeRetourReel);
	
	$req->execute();
  }

  try
{
$db = new PDO('mysql:host=localhost;dbname=Pret','root' ,'root' );
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$base = new GestionPret($db);
$base->gestionPret("essai", 15,2);

}
catch (Exception $e)
{
die('Erreur : ' . $e->getMessage());
}

?>
</body>
</html>