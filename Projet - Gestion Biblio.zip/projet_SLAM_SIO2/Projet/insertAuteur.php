<?php
// Connexion à MySQL
$bdd = new PDO("mysql:host=127.0.0.1;dbname=biblio2016;charset=utf8", "root", "");

if(isset($_POST['num']))   // Si la variable $_POST['num'] est bien définie
{ 
   $nom = htmlspecialchars($_POST['nom']);
   $prenom = htmlspecialchars($_POST['prenom']);
   $nationalite = htmlspecialchars($_POST['nationalite']); 

   // Requête d'insertion
   $insertion = $bdd->prepare("INSERT INTO auteur (num, nom, prenom, nationalite) VALUES ('$num', '$nom', '$prenom', '$nationalite')");

   // Exécution de la reqête
   $insertion->execute(array($nom,$prenom,$nationalite,$_POST['num']));
   echo 'Bienvenue';

}
?>
<a href="tableauAuteur.php" target="_blank"><input type="button" value="Inserer"><br></br></a>

<html>
  <head>
    <title>Insérer un auteur</title>
  </head>
   <body>
      <form name="insertion" action="insertion3.php" method="POST">
      <table border="0" align="center" cellspacing="2" cellpadding="2">
         <tr align="center">
            <td>Nom</td>
            <td>
               <input type="text" name="nom"></td>
         </tr>
         <tr align="center">
            <td>Prenom</td>
            <td>
               <input type="text" name="prenom"></td>
         </tr>
         <tr align="center">
            <td>Nationalie</td>
               <td><input type="text" name="nationalite"></td>
         </tr>
 
         <tr align="center">
            <td colspan="2"><input type="submit" value="Inserer"></td>
         </tr>
      </table>
      </form>
   </body>
</html>