<?php
$bdd = new PDO("mysql:host=127.0.0.1;dbname=biblio2016;charset=utf8", "root", "");

if(isset($_POST['num']))
{
	$ISBN = htmlspecialchars($_POST['ISBN']);
	$titre = htmlspecialchars($_POST['titre']);
	$prix = htmlspecialchars($_POST['prix']);
	$editeur = htmlspecialchars($_POST['editeur']);
	$annee = htmlspecialchars($_POST['annee']);
	$langue = htmlspecialchars($_POST['langue']);
	$numAuteur = htmlspecialchars($_POST['numAuteur']);
	$numGenre = htmlspecialchars($_POST['numGenre']);
	
	$insertnom = $bdd->prepare("UPDATE livre SET ISBN = ?, titre = ?, prix = ?, editeur = ?, annee = ?, langue = ?, numAuteur = ?, numGenre = ? WHERE num=?");
	$insertnom->execute(array($ISBN,$titre,$prix,$editeur,$annee,$langue,$numAuteur,$numGenre,$_POST['num']));
	echo 'élément mit à jour ';
}
?>
<a href="tableaulivre.php" target="_blank"><input type="button" value="Retour"><br></br></a>