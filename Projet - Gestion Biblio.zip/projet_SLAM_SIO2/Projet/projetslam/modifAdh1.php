<?php
$bdd = new PDO("mysql:host=127.0.0.1;dbname=biblio2016;charset=utf8", "root", "");

if(isset($_POST['num']))
{
	$nom = htmlspecialchars($_POST['nom']);
	$prenom = htmlspecialchars($_POST['prenom']);
	$adrRue = htmlspecialchars($_POST['adrRue']);
	$adrCP = htmlspecialchars($_POST['adrCP']);
	$adrVille = htmlspecialchars($_POST['adrVille']);
	$tel = htmlspecialchars($_POST['tel']);
	$mel = htmlspecialchars($_POST['mel']);
	
	$insertnom = $bdd->prepare("UPDATE adherent SET nom = ?, prenom = ?, adrRue = ?, adrCP = ?, adrVille = ?, tel = ?, mel = ? WHERE num=?");
	$insertnom->execute(array($nom,$prenom,$adrRue,$adrCP,$adrVille,$tel,$mel,$_POST['num']));
	echo 'élément mit à jour ';
}
?>
<a href="tableauAdherent.php" target="_blank"><input type="button" value="Retour"><br></br></a>