<?php
// Connexion à MySQL
$bdd = new PDO("mysql:host=127.0.0.1;dbname=biblio2016;charset=utf8", "root", "");

if(isset($_POST['num']))   // Autre contrôle pour vérifier si la variable $_POST['Bouton'] est bien définie
{ 
   $nom = htmlspecialchars($_POST['nom']);
   $prenom = htmlspecialchars($_POST['prenom']);
   $adrRue = htmlspecialchars($_POST['adrRue']);
   $adrCP = htmlspecialchars($_POST['adrCP']);
   $adrVille = htmlspecialchars($_POST['adrVille']);
   $tel = htmlspecialchars($_POST['tel']);
   $mel = htmlspecialchars($_POST['mel']);

$req = "Supprimer |
 
        DROP TRIGGER IF EXISTS 'mise_a_null_livre_auteur';
        CREATE DEFINER='root@localhost' TRIGGER 'mise_a_null_livre_auteur'
        BEFORE DELETE ON 'auteur'
          FOR EACH ROW UPDATE livre
          	SET numAuteur = NULL
          	WHERE numAuteur=old.num
          END;
        |
        ";
mysql_query($req,$bdd);
?>