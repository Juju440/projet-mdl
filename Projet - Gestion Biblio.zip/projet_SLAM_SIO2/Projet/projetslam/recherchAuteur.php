<?php
// Connexion à MySQL
$bdd = new PDO("mysql:host=127.0.0.1;dbname=biblio2016;charset=utf8", "root", "");

if(isset($_POST['num']))   // Autre contrôle pour vérifier si la variable $_POST['num'] est bien définie
{ 
   	$nom = htmlspecialchars($_POST['nom']);
   	$prenom = htmlspecialchars($_POST['prenom']);
   	$nationalite = htmlspecialchars($_POST['nationalite']);


 	//Requête
	$search = $bdd->prepare("SELECT * FROM auteur WHERE prenom LIKE ('".$_POST['prenom']."')");
	echo "<TABLE Border=1 bordercolor=\"#000000\" CellSpacing=0>";
	echo "<TR>";
	echo "<TD><B>Nom</B></TD>";
	echo "<TD><B>Prenom</B></TD>";
	echo "<TD><B>Nationalite</B></TD>";
	echo "</TR>";
	while ($LigneCourante = mysql_fetch_assoc($search)) 
	{
   		echo "<TR>";
   		echo "<TD>".$LigneCourante["Nom"]."</TD>";
   		echo "<TD>".$LigneCourante["Prenom"]."</TD>";
   		echo "<TD>".$LigneCourante["Nationalite"]."</TD>";
   		echo "</TR>";
	}
	echo "</TABLE>";

 	// Exécution de la reqête
   	$search->execute(array($nom,$prenom,$nationalite,$_POST['num']));
   	echo 'Recherche';
}
?>
<a href="tableauAuteur.php" target="_blank"><input type="button" value="Recherche"><br></br></a>
