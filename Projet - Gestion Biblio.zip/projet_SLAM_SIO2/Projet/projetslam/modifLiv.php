 <?php

 $bdd = new PDO("mysql:host=127.0.0.1;dbname=biblio2016;charset=utf8", "root", "");
if(isset($_GET['num']))
{

	$livre = $bdd->prepare("SELECT * FROM livre WHERE num = ?");
	$livre->execute(array($_GET['num']));
	$liv = $livre->fetch();

?>
<form action="modifLiv1.php" method="post">
	<input type="hidden" name="num" value="<?php echo $liv['num']?>" />
	<label><p>ISBN</p></label>
	<input type="text" name="ISBN" value="<?php echo $liv['ISBN'] ?>" >
	<label><p>titre</p></label>
	<input type="text" name="titre" value="<?php echo $liv['titre'] ?>">
	<label><p>prix</p></label>
	<input type="text" name="prix" value="<?php echo $liv['prix'] ?>">
	<label><p>editeur</p></label>
	<input type="text" name="editeur" value="<?php echo $liv['editeur'] ?>">
	<label><p>annee</p></label>
	<input type="text" name="annee" value="<?php echo $liv['annee'] ?>">
	<label><p>langue</p></label>
	<input type="text" name="langue" value="<?php echo $liv['langue'] ?>">
	<label><p>numAuteur</p></label>
	<input type="text" name="numAuteur" value="<?php echo $liv['numAuteur'] ?>">
	<label><p>numGenre</p></label>
	<input type="text" name="numGenre" value="<?php echo $liv['numGenre'] ?>">
	

<input type="submit" name="valider" value="valider">
</form>
<?php
}
?>