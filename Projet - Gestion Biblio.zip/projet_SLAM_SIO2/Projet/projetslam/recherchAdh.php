<?php
// Connexion à MySQL
$bdd = new PDO("mysql:host=127.0.0.1;dbname=biblio2016;charset=utf8", "root", "");

if(isset($_POST['num']))   // Autre contrôle pour vérifier si la variable $_POST['num'] est bien définie
{ 
   	$nom = htmlspecialchars($_POST['nom']);
   	$prenom = htmlspecialchars($_POST['prenom']);
   	$adrRue = htmlspecialchars($_POST['adrRue']);
   	$adrCP = htmlspecialchars($_POST['adrCP']);
   	$adrVille = htmlspecialchars($_POST['adrVille']);
   	$tel = htmlspecialchars($_POST['tel']);
   	$mel = htmlspecialchars($_POST['mel']);

 	//Requête
	$search = $bdd->prepare("SELECT * FROM adherent WHERE prenom LIKE ('".$_POST['prenom']."')");
	echo "<TABLE Border=1 bordercolor=\"#000000\" CellSpacing=0>";
	echo "<TR>";
	echo "<TD><B>Nom</B></TD>";
	echo "<TD><B>Prenom</B></TD>";
	echo "<TD><B>Adresse Rue</B></TD>";
	echo "<TD><B>Code Postal</B></TD>";
	echo "<TD><B>Ville</B></TD>";
	echo "<TD></B>Numero telephone</B></TD>";
	echo "<TD></B>Mail</B></TD>";
	echo "</TR>";
	while ($LigneCourante = mysql_fetch_assoc($search)) 
	{
   		echo "<TR>";
   		echo "<TD>".$LigneCourante["Nom"]."</TD>";
   		echo "<TD>".$LigneCourante["Prenom"]."</TD>";
   		echo "<TD>".$LigneCourante["Adresse Rue"]."</TD>";
   		echo "<TD>".$LigneCourante['Code Postal']."</TD>";
   		echo "<TD>".$LigneCourante["Ville"]."</TD>";
   		echo "<TD>".$LigneCourante["Numero telephone"]."</TD>";
   		echo "<TD>".$LigneCourante["Mail"]."</TD>";
   		echo "</TR>";
	}
	echo "</TABLE>";

 	// Exécution de la reqête
   	$search->execute(array($nom,$prenom,$adrRue,$adrCP,$adrVille,$tel,$mel,$_POST['num']));
   	echo 'Recherche';
}
?>
<a href="tableauAdherent.php" target="_blank"><input type="button" value="Recherche"><br></br></a>
