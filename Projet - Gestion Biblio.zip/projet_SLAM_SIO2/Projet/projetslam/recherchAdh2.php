<?php
switch($cmdAction) 
{
    case "Rechercher":
        // Connexion à MySQL
        $bdd = new PDO("mysql:host=127.0.0.1;dbname=biblio2016;charset=utf8", "root", "");

        if(isset($_POST['num']))   // Autre contrôle pour vérifier si la variable $_POST['num'] est bien définie
        { 
          $nom = htmlspecialchars($_POST['nom']);
          $prenom = htmlspecialchars($_POST['prenom']);
          $adrRue = htmlspecialchars($_POST['adrRue']);
          $adrCP = htmlspecialchars($_POST['adrCP']);
          $adrVille = htmlspecialchars($_POST['adrVille']);
          $tel = htmlspecialchars($_POST['tel']);
          $mel = htmlspecialchars($_POST['mel']);


          //Requête
          $search = $bdd->prepare("SELECT * FROM adherent WHERE prenom LIKE ('".$_POST['prenom']."')");
          echo "<TABLE Border=1 bordercolor=\"#000000\" CellSpacing=0>";
          echo "<TR>";
          echo "<TD><B>Nom</B></TD>";
          echo "<TD><B>Prenom</B></TD>";
          echo "<TD><B>Adresse Rue</B></TD>";
          echo "<TD><B>Code Postal</B></TD>";
          echo "<TD><B>Ville</B></TD>";
          echo "<TD></B>Numero telephone</B></TD>";
          echo "<TD></B>Mail</B></TD>";
          echo "</TR>";
          while ($LigneCourante = mysql_fetch_assoc($search)) 
          {
            echo "<TR>";
            echo "<TD>".$LigneCourante["Nom"]."</TD>";
            echo "<TD>".$LigneCourante["Prenom"]."</TD>";
            echo "<TD>".$LigneCourante["Adresse Rue"]."</TD>";
            echo "<TD>".$LigneCourante['Code Postal']."</TD>";
            echo "<TD>".$LigneCourante["Ville"]."</TD>";
            echo "<TD>".$LigneCourante["Numero telephone"]."</TD>";
            echo "<TD>".$LigneCourante["Mail"]."</TD>";
            echo "</TR>";
          }
          echo "</TABLE>";

          // Exécution de la reqête
          $search->execute(array($nom,$prenom,$adrRue,$adrCP,$adrVille,$tel,$mel,$_POST['num']));
          echo 'Recherche';
        }
          break;
      default:
          // Entrée du programme la première fois
          echo "<form name=\"frmCurrEdit\" method=\"post\" action=\"recherche.php\">";
          echo "Votre numero de recherche: ";
          echo "<SELECT name=MonNumero>";
          echo "<OPTION value=\"1\">1";
          echo "<OPTION value=\"2\">2";
          echo "<OPTION value=\"3\">3";
          echo "<OPTION value=\"4\">4";
          echo "<OPTION value=\"5\">5";
          echo "<OPTION value=\"6\">6";
          echo "<OPTION value=\"7\">7";
          echo "<OPTION value=\"8\">8";
          echo "<OPTION value=\"9\">9";
          echo "<OPTION value=\"10\">10";
          echo "<OPTION value=\"11\">11";
          echo "<OPTION value=\"12\">12";
          echo "<OPTION value=\"13\">13";
          echo "<OPTION value=\"14\">14";
          echo "<OPTION value=\"15\">15";
          echo "<OPTION value=\"16\">16";
          echo "<OPTION value=\"17\">17";
          echo "<OPTION value=\"18\">18";
          echo "<OPTION value=\"19\">19";
          echo "<OPTION value=\"20\">20";
          echo "</SELECT><BR>";
          echo "<input class=bouton type=\"submit\" name=\"cmdAction\" value=\"Rechercher\">";
          echo "</form>";
          break;
}
?>