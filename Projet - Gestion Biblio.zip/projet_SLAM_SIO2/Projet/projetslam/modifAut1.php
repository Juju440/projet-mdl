<?php
$bdd = new PDO("mysql:host=127.0.0.1;dbname=biblio2016;charset=utf8", "root", "");

if(isset($_POST['num']))
{
	$nom = htmlspecialchars($_POST['nom']);
	$prenom = htmlspecialchars($_POST['prenom']);
	$nationalite = htmlspecialchars($_POST['nationalite']);
	$insertnom = $bdd->prepare("UPDATE auteur SET nom = ?, prenom = ?, nationalite = ? WHERE num=?");
	$insertnom->execute(array($nom,$prenom,$nationalite,$_POST['num']));
	echo 'élément mit à jour ';
}
?>
<a href="tableauAuteur.php" target="_blank"><input type="button" value="Retour"><br></br></a>