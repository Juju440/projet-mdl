 <?php

 $bdd = new PDO("mysql:host=127.0.0.1;dbname=biblio2016;charset=utf8", "root", "");
if(isset($_GET['num']))
{

	$auteur = $bdd->prepare("SELECT * FROM auteur WHERE num = ?");
	$auteur->execute(array($_GET['num']));
	$aut = $auteur->fetch();

?>
<form action="modifAut1.php" method="post">
	<input type="hidden" name="num" value="<?php echo $aut['num']?>" />
	<label><p>Nom</p></label>
	<input type="text" name="nom" value="<?php echo $aut['nom'] ?>" >
	<label><p>Prenom</p></label>
	<input type="text" name="prenom" value="<?php echo $aut['prenom'] ?>">
	<label><p>adrRue</p></label>
	<input type="text" name="nationalite" value="<?php echo $aut['nationalite'] ?>">
	

<input type="submit" name="valider" value="valider">
</form>
<?php
}
?>