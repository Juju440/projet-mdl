<?php
switch($cmdAction) 
{
    case "Rechercher":
        // Connexion à MySQL
        $bdd = new PDO("mysql:host=127.0.0.1;dbname=biblio2016;charset=utf8", "root", "");

        if(isset($_POST['num']))   // Autre contrôle pour vérifier si la variable $_POST['num'] est bien définie
        { 
          $nom = htmlspecialchars($_POST['nom']);
          $prenom = htmlspecialchars($_POST['prenom']);
          $nationalite = htmlspecialchars($_POST['nationalite']);


          //Requête
          $search = $bdd->prepare("SELECT * FROM auteur WHERE prenom LIKE ('".$_POST['prenom']."')");
          echo "<TABLE Border=1 bordercolor=\"#000000\" CellSpacing=0>";
          echo "<TR>";
          echo "<TD><B>Nom</B></TD>";
          echo "<TD><B>Prenom</B></TD>";
          echo "<TD><B>Nationalite</B></TD>";
          echo "</TR>";
          while ($LigneCourante = mysql_fetch_assoc($search)) 
          {
            echo "<TR>";
            echo "<TD>".$LigneCourante["Nom"]."</TD>";
            echo "<TD>".$LigneCourante["Prenom"]."</TD>";
            echo "<TD>".$LigneCourante["Nationalite"]."</TD>";
            echo "</TR>";
          }
          echo "</TABLE>";

          // Exécution de la reqête
          $search->execute(array($nom,$prenom,$nationalite,$_POST['num']));
          echo 'Recherche';
        }
          break;
      default:
          // Entrée du programme la première fois
          echo "<form name=\"frmCurrEdit\" method=\"post\" action=\"recherche2.php\">";
          echo "Votre numero de recherche: ";
          echo "<SELECT name=MonNumero>";
          echo "<OPTION value=\"1\">1";
          echo "<OPTION value=\"2\">2";
          echo "<OPTION value=\"3\">3";
          echo "<OPTION value=\"4\">4";
          echo "<OPTION value=\"5\">5";
          echo "<OPTION value=\"6\">6";
          echo "<OPTION value=\"7\">7";
          echo "<OPTION value=\"8\">8";
          echo "<OPTION value=\"9\">9";
          echo "<OPTION value=\"10\">10";
          echo "<OPTION value=\"11\">11";
          echo "<OPTION value=\"12\">12";
          echo "<OPTION value=\"13\">13";
          echo "<OPTION value=\"14\">14";
          echo "<OPTION value=\"15\">15";
          echo "<OPTION value=\"16\">16";
          echo "<OPTION value=\"17\">17";
          echo "<OPTION value=\"18\">18";
          echo "<OPTION value=\"19\">19";
          echo "<OPTION value=\"20\">20";
          echo "<OPTION value=\"21\">21";
          echo "<OPTION value=\"22\">22";
          echo "<OPTION value=\"23\">23";
          echo "<OPTION value=\"24\">24";
          echo "<OPTION value=\"25\">25";                              
          echo "</SELECT><BR>";
          echo "<input class=bouton type=\"submit\" name=\"cmdAction\" value=\"Rechercher\">";
          echo "</form>";
          break;
}
?>