<?php
// Connexion à MySQL
$bdd = new PDO("mysql:host=127.0.0.1;dbname=biblio2016;charset=utf8", "root", "");

if(isset($_POST['num']))   // Autre contrôle pour vérifier si la variable $_POST['num'] est bien définie
{ 
   $isbn = htmlspecialchars($_POST['isbn']);
   $titre = htmlspecialchars($_POST['titre']);
   $prix = htmlspecialchars($_POST['prix']);
   $editeur = htmlspecialchars($_POST['editeur']);
   $annee = htmlspecialchars($_POST['annee']);
   $langue = htmlspecialchars($_POST['langue']);

   // Requête
   $search = $bdd->prepare("SELECT * FROM livre WHERE titre LIKE ('".$_POST['titre']."')");
	echo "<TABLE Border=1 bordercolor=\"#000000\" CellSpacing=0>";
	echo "<TR>";
	echo "<TD><B>ISBN</B></TD>";
	echo "<TD><B>Titre</B></TD>";
	echo "<TD><B>Prix</B></TD>";
	echo "<TD><B>Editeur</B></TD>";
	echo "<TD></B>Annee</B></TD>";
	echo "<TD></B>Langue</B></TD>";
	echo "</TR>";
	while ($LigneCourante = mysql_fetch_assoc($search)) 
	{
   		echo "<TR>";
   		echo "<TD>".$LigneCourante["ISBN"]."</TD>";
   		echo "<TD>".$LigneCourante["Titre"]."</TD>";
   		echo "<TD>".$LigneCourante["Prix"]."</TD>";
   		echo "<TD>".$LigneCourante["Editeur"]."</TD>";
   		echo "<TD>".$LigneCourante["Annee"]."</TD>";
   		echo "<TD>".$LigneCourante["Langue"]."</TD>";
   		echo "</TR>";
	}
	echo "</TABLE>";

 	// Exécution de la reqête
   	$search->execute(array($isbn,$titre,$prix,$editeur,$annee,$langue,$_POST['num']));
   	echo 'Recherche';
}
?>
<a href="tableauLivre.php" target="_blank"><input type="button" value="Recherche"><br></br></a>
