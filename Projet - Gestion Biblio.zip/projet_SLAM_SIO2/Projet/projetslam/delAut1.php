<?php
$bdd = new PDO("mysql:host=127.0.0.1;dbname=biblio2016;charset=utf8", "root", "");

if(isset($_POST['num']))
{
	
	$delAut = $bdd->prepare("DELETE FROM auteur WHERE num=?");
	$delAut->execute(array($_POST['num']));
	
	echo 'élément mit à jour ';
}
?>
<a href="tableauAuteur.php" target="_blank"><input type="button" value="Retour"><br></br></a>