<?php

 $bdd = new PDO("mysql:host=127.0.0.1;dbname=biblio2016;charset=utf8", "root", "");
if(isset($_GET['num']))
{

	$auteur = $bdd->prepare("SELECT * FROM auteur WHERE num = ?");
	$auteur->execute(array($_GET['num']));
	$aut = $auteur->fetch();

?>
<form action="delAut1.php" method="post">
	<input type="hidden" name="num" value="<?php echo $aut['num']?>" />

	<input type="submit" name="Confirmer" value="Confirmer">
</form>
<?php
}
?>