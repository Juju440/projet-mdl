<?php
// Connexion à MySQL
$bdd = new PDO("mysql:host=127.0.0.1;dbname=biblio2016;charset=utf8", "root", "");

if(isset($_POST['num']))   // Autre contrôle pour vérifier si la variable $_POST['Bouton'] est bien définie
{ 
   $nom = htmlspecialchars($_POST['nom']);
   $prenom = htmlspecialchars($_POST['prenom']);
   $adrRue = htmlspecialchars($_POST['adrRue']);
   $adrCP = htmlspecialchars($_POST['adrCP']);
   $adrVille = htmlspecialchars($_POST['adrVille']);
   $tel = htmlspecialchars($_POST['tel']);
   $mel = htmlspecialchars($_POST['mel']); 

   // Requête d'insertion
   $insertion = $bdd->prepare("INSERT INTO adherent (num, nom, prenom, adrRue, adrCP, adrVille, tel, mail) VALUES ('$num', '$nom', '$prenom', '$adrRue', '$adrCP', '$adrVille', '$tel', '$mail')");

   // Exécution de la reqête
   $insertion->execute(array($nom,$prenom,$adrRue,$adrCP,$adrVille,$tel,$mel,$_POST['num']));
   echo 'Bienvenue';

}
?>
<a href="tableauAdherent.php" target="_blank"><input type="button" value="Inserer"><br></br></a>

<form name="insertion" action="insertion2.php" method="POST">
      <table border="0" align="center" cellspacing="2" cellpadding="2">
         <tr align="center">
            <td>Nom</td>
            <td>
               <input type="text" name="nom"></td>
         </tr>
         <tr align="center">
            <td>Prenom</td>
            <td>
               <input type="text" name="prenom"></td>
         </tr>
         <tr align="center">
            <td>Adresse Rue</td>
               <td><input type="text" name="adrRue"></td>
         </tr>
         <tr align="center">
            <td>Code Postal</td>
               <td><input type="text" name="adrCP"></td>
         </tr>
         <tr align="center">
            <td>Ville</td>
               <td><input type="text" name="adrVille"></td>
         </tr>
         <tr align="center">
            <td>Numero de telephone</td>
               <td><input type="text" name="tel"></td>
         </tr>
         <tr align="center">
            <td>Mail</td>
               <td><input type="text" name="mail"></td>
         </tr>
 
         <tr align="center">
            <td colspan="2"><input type="submit" value="Inserer"></td>
         </tr>
      </table>
      </form>