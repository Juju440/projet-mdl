<?php
// Connexion à MySQL
$bdd = new PDO("mysql:host=127.0.0.1;dbname=biblio2016;charset=utf8", "root", "");

if(isset($_POST['num']))   // Si la variable $_POST['num'] est bien définie
{ 
   $isbn = htmlspecialchars($_POST['isbn']);
   $titre = htmlspecialchars($_POST['titre']);
   $prix = htmlspecialchars($_POST['prix']);   
   $editeur = htmlspecialchars($_POST['editeur']);
   $annee = htmlspecialchars($_POST['annee']);
   $langue = htmlspecialchars($_POST['langue']);


   // Requête d'insertion
   $insertion = $bdd->prepare("INSERT INTO livre (num, isbn, titre, prix, editeur, annee, langue) VALUES ('$num', $isbn', '$titre', '$prix', '$editeur', '$annee', '$langue')");

   // Exécution de la reqête
   $insertion->execute(array($isbn,$titre,$prix,$editeur,$annee,$langue,$_POST['num']));
   echo 'Bienvenue';

}
?>
<a href="tableauLivre.php" target="_blank"><input type="button" value="Inserer"><br></br></a>

<html>
  <head>
    <title>Insérer un livre</title>
  </head>
	<body>
		<form name="insertion" action="insertion4.php" method="POST">
  		<table border="0" align="center" cellspacing="2" cellpadding="2">
    		<tr align="center">
      		<td>ISBN</td>
      		<td>
      			<input type="text" name="isbn"></td>
    		</tr>
    		<tr align="center">
      		<td>Titre</td>
      		<td>
      			<input type="text" name="titre"></td>
    		</tr>
    		<tr align="center">
      		<td>Prix</td>
      			<td><input type="text" name="prix"></td>
    		</tr>
    		<tr align="center">
      		<td>Editeur</td>
      			<td><input type="text" name="editeur"></td>
    		</tr>
    		<tr align="center">
      		<td>Annee</td>
      			<td><input type="text" name="annee"></td>
    		</tr>
    		<tr align="center">
      		<td>Langue</td>
      			<td><input type="text" name="langue"></td>
    		</tr>
 
    		<tr align="center">
      		<td colspan="2"><input type="submit" value="Inserer"></td>
    		</tr>
 		</table>
		</form>
	</body>
</html>