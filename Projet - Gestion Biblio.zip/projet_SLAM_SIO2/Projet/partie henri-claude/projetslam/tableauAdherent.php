<?php $bdd = new PDO('mysql:host=localhost;dbname=biblio2016;charset=utf8', 'root', ''); ?>



<head>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous"> 
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">


	<style>
	.table{
		margin: auto;
		width: 500px;
	}
    </style>
</head>

<table class="table" >
	<thead>	
		<tr>
			<th scope="col">Id</th>
			<th scope="col">Nom</th>
			<th scope="col">Prenom</th>
			<th scope="col">Adresse</th>
			<th scope="col">Code Postal</th>
			<th scope="col">Ville</th>
			<th scope="col">Tel</th>
			<th scope="col">Mail</th>
			<th scope="col">Modifier</th>
			<th scope="col">Supprimer</th>

		</tr>
	</thead>

	<tbody>
		<?php $req = $bdd->query('SELECT * FROM adherent');
		while ($adherent = $req->fetch()) {
		?>
			<tr>
			<th scope="row"><?php echo $adherent['num'] ?></th>
			<td><?php echo $adherent['nom'] ?></td>
			<td><?php echo $adherent['prenom'] ?></td>
			<td><?php echo $adherent['adrRue'] ?></td>
			<td><?php echo $adherent['adrCP'] ?></td>
			<td><?php echo $adherent['adrVille'] ?></td>
			<td><?php echo $adherent['tel'] ?></td>
			<td><?php echo $adherent['mel'] ?></td>
			<td><a href="modifAdh.php?num=<?php echo $adherent['num']?>"><i class="fas fa-pencil-alt"></i></a></td>
			<td><a href="index.php?num=<?php echo $adherent['num']?>"><i class="fas fa-trash-alt"style="color: red;"></i></a></td>

		</tr>
		<?php
		}
        ?>

		 
		
	</tbody>
</table>