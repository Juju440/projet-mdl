

<head>
	<p class="" style= "margin: auto";
> Liste des Adherents</p>
<div class="adh">
<?php

include('tableauAdherent.php');
?>
</div>
<head>
	<p class="" style= "margin: auto";
"> Liste des Auteurs</p>
<div class="aut">
<?php
include('tableauAuteur.php');
?>
</div>
<head>
	<p class="" style= "margin: auto";
"> Liste des Livres</p>
<div class="liv">
<?php
include('tableauLivre.php');
?>
</div>