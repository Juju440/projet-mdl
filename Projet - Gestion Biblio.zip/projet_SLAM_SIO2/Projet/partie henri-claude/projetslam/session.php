<?php
	
	$Droits_Admin="1";
	$login_valide= //mettre la requête concernée
	$pwd_valide= //mettre la requête concernée
	
// se connecter par rapport aux droits // 	

    while (isset($_POST['login']) && isset($_POST['pwd'])) {
	
					$req1 = mysqli_query($base, "SELECT login FROM utilisateurs WHERE login = 'administrateur' ");
					$req2 = mysqli_query($base, "SELECT pswd FROM utilisateurs WHERE pswd = 'test' ");

		if ( $login_valide == $req1 && $pwd_valide == $req2 ) 
		{
			
			$_SESSION['droits']= "1";
			
			header("Location: listecommande.php");
		}
		else 
		
		{
			header("Location: ..."); //page à afficher

		}
	}
	else 
	
	{
		echo 'Les variables du formulaire ne sont pas déclarées.';
    }
	
    ?>