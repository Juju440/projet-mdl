<?php
$servername = "localhost";
$username = "username";
$password = "password";
$dbname = "myDBPDO";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $sql = "UPDATE MyGuests SET lastname='Doe' WHERE id=2";

    // Prepare statement
    $stmt = $conn->prepare($sql);

    // execute the query
    $stmt->execute();

    // echo a message to say the UPDATE succeeded
    echo $stmt->rowCount() . " records UPDATED successfully";
    }
catch(PDOException $e)
    {
    echo $sql . "<br>" . $e->getMessage();
    }

$conn = null;
if(!empty($_POST['valid']))
	{
    	$bddmembre2 = $bddreq->prepare("UPDATE validhs SET id=:n0, nom=:n1, datehs=:n2, heure=:n3, com=:n4, demande=:n5 valid=:n6, WHERE id=:n0");
 
 
		$vid = ($_POST['id']);
		$vnom = ($_POST['nom']);
		$vdatehs = ($_POST['datehs']);
		$vheure = ($_POST['heure']);
		$vcom = ($_POST['com']);
		$vdemande = ($_POST['demande']);
		$vvalid = ($_POST['valid']);

		$bddmembre2->execute(array(
			':n0' => $vid,
			':n1' => $vnom,
			':n2' => $vdatehs,
			':n3' => $vheure,
			':n4' => $vcom,
			':n5' => $vdemande,
			':n6' => $vvalid
 
			));
?>
