<?php $bdd = new PDO('mysql:host=localhost;dbname=biblio2016;charset=utf8', 'root', ''); ?>

<head>
	
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous"> 
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">


	<style>
	.table{
		margin: auto;
		width: 500px;
	}
    </style>
</head>

<table class="table" >
	<thead>	
		<tr>
			<th scope="col">Id</th>
			<th scope="col">Nom</th>
			<th scope="col">Prenom</th>
			<th scope="col">Nationalité</th>
			<th scope="col">Modifier</th>
			<th scope="col">Supprimer</th>

		</tr>
	</thead>

	<tbody>
		<?php $req = $bdd->query('SELECT * FROM auteur');
		while ($auteur = $req->fetch()) {
		?>
			<tr>
			<th scope="row"><?php echo $auteur['num'] ?></th>
			<td><?php echo $auteur['nom'] ?></td>
			<td><?php echo $auteur['prenom'] ?></td>
			<td><?php echo $auteur['nationalite'] ?></td>
			<td><a href="modifAut.php?num=<?php echo $adherent['num']?>"><i class="fas fa-pencil-alt"></i></a></td>
			<td><a href="index.php?num=<?php echo $adherent['num']?>"><i class="fas fa-trash-alt"style="color: red;"></i></a></td>

		</tr>
		<?php
		}
        ?>

		 
		
	</tbody>
</table>