<?php
$bdd = new PDO("mysql:host=127.0.0.1;dbname=biblio2016;charset=utf8", "root", "");

if(isset($_POST['num']))
{
	$nom = htmlspecialchars($_POST['nom']);
	$prenom = htmlspecialchars($_POST['prenom']);
	$insertnom = $bdd->prepare("UPDATE adherent SET nom = ?, prenom = ? WHERE num=?");
	$insertnom->execute(array($nom,$prenom,$_POST['num']));
	echo 'élément mit à jour ';
}
?>