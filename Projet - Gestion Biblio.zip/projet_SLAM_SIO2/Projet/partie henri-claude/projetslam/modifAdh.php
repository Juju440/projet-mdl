 <?php

 $bdd = new PDO("mysql:host=127.0.0.1;dbname=biblio2016;charset=utf8", "root", "");
if(isset($_GET['num']))
{

	$adherent = $bdd->prepare("SELECT * FROM adherent WHERE num = ?");
	$adherent->execute(array($_GET['num']));
	$adh = $adherent->fetch();

?>
<form action="modifAdh1.php" method="post">
	<input type="hidden" name="num" value="<?php echo $adh['num']?>" />
	<label><p>Nom</p></label>
	<input type="text" name="nom" value="<?php echo $adh['nom'] ?>" >
	<label><p>Prenom</p></label>
	<input type="text" name="prenom" value="<?php echo $adh['prenom'] ?>">
	<label><p>adrRue</p></label>
	<input type="text" name="adrRue" value="<?php echo $adh['adrRue'] ?>">
	<label><p>adrCP</p></label>
	<input type="text" name="adrCP" value="<?php echo $adh['adrCP'] ?>">
	<label><p>adrVille</p></label>
	<input type="text" name="adrVille" value="<?php echo $adh['adrVille'] ?>">
	<label><p>tel</p></label>
	<input type="text" name="tel" value="<?php echo $adh['tel'] ?>">
	<label><p>mel</p></label>
	<input type="text" name="mel" value="<?php echo $adh['mel'] ?>">

<input type="submit" name="valider" value="valider">
</form>
<?php
}
?>